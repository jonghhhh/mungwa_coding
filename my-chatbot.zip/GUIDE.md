# 📖 Gemini 챗봇 개발/배포 가이드

## 1. 사전 준비

| 항목 | URL |
|------|-----|
| Google 계정 (Gemini API Key) | https://aistudio.google.com/apikey |
| Hugging Face 계정 (배포용) | https://huggingface.co/join |
| VS Code | https://code.visualstudio.com/ |
| Python 3.10+ | https://www.python.org/downloads/ |
| Git | https://git-scm.com/downloads |

---

## 2. API Key / Token 발급

### Gemini API Key
1. https://aistudio.google.com/apikey 접속 → Google 로그인
2. **"Create API Key"** 클릭 → 복사 후 보관

### Hugging Face Token
1. https://huggingface.co/settings/tokens 접속
2. **"Create new token"** → Type: **Write** → 생성 후 복사

---

## 3. 로컬 개발 (VS Code 터미널)

```bash
# 프로젝트 폴더로 이동 (프로젝트 폴더를 my-chatbot라고 할 때)
cd my-chatbot경로

# 가상환경 생성
python -m venv .venv

# 가상환경 활성화
# macOS/Linux:
source .venv/bin/activate
# Windows:
.venv\Scripts\activate

# 라이브러리 설치
pip install -r requirements.txt

# 서버 실행
python app.py
```

→ http://localhost:7860 에서 챗봇 확인

---

## 4. Hugging Face Spaces 배포

### Step 1: Space 생성 (웹 브라우저)

1. https://huggingface.co/new-space 접속
2. 설정:
   - **Space name**: `my-chatbot` (원하는 이름)
   - **SDK**: **Gradio** ← 반드시 Gradio 선택
   - **Hardware**: Free (CPU basic)
   - **Visibility**: Public
3. **Create Space** 클릭

### Step 2: 배포 (VS Code 터미널)

```bash
# HF CLI 설치 (이미 설치되어 있으면 생략)
pip install huggingface_hub

# HF 로그인 (Token 입력)
huggingface-cli login

# Space 클론
git clone https://huggingface.co/spaces/YOUR_USERNAME/my-chatbot
cd my-chatbot

# 파일 복사 (app.py, requirements.txt, .gitignore)
# → 원본 프로젝트에서 위 3개 파일을 이 폴더에 복사

# 배포
git add .
git commit -m "Initial deploy"
git push
```

### Step 3: 확인

- Space 페이지에서 **Building → Running** 전환 확인
- 접속: `https://YOUR_USERNAME-my-chatbot.hf.space`

---

## 5. 배포에 필요한 파일 (3개)

```
my-chatbot/
├── app.py              ← 챗봇 메인 코드
├── requirements.txt    ← 라이브러리 목록
└── .gitignore          ← 업로드 제외 목록
```

> Dockerfile은 필요 없음. Gradio SDK가 환경을 자동 설정합니다.

---

## (부록) 6. 실험용: 대화 로그 자동 수집 (HF Dataset)

실험 참여자들의 대화 내용을 연구자가 수집해야 할 경우, HF Dataset에 자동 저장할 수 있습니다. 참여자는 아무것도 할 필요 없고, 대화가 저장될 때마다 연구자의 비공개 Dataset에 자동 기록됩니다.

### 원리

```
참여자가 "대화 저장" 클릭
  → JSON 파일이 연구자의 비공개 HF Dataset에 자동 업로드
  → 연구자는 Dataset 페이지에서 전체 로그 확인/다운로드
```

### 설정 방법 (3단계)

**① 비공개 Dataset 생성**

1. https://huggingface.co/new-dataset 접속
2. Dataset name: `chatbot-logs` (원하는 이름)
3. **Private** 선택 → Create

**② Space에 HF Token 등록**

1. Space 페이지 → **Settings** → **Variables and secrets**
2. **New secret** 클릭:
   - Name: `HF_TOKEN`
   - Value: Write 권한의 HF Token 붙여넣기

**③ app.py에 자동 저장 코드 추가**

`save_chat()` 함수를 아래처럼 수정:

```python
from huggingface_hub import HfApi
import uuid

def save_chat(chat_history):
    """대화 기록을 저장합니다. HF Dataset이 설정되어 있으면 자동 업로드."""
    if not chat_history:
        return gr.update(value=None)

    # 로컬 파일 저장 (기존과 동일)
    now = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    session_id = uuid.uuid4().hex[:8]
    filename = f"chat_{now}_{session_id}.json"
    filepath = os.path.join("saved_chats", filename)

    os.makedirs("saved_chats", exist_ok=True)
    with open(filepath, "w", encoding="utf-8") as f:
        json.dump(chat_history, f, ensure_ascii=False, indent=2)

    # HF Dataset에 업로드 (HF_TOKEN이 있을 때만)
    hf_token = os.environ.get("HF_TOKEN")
    if hf_token:
        try:
            api = HfApi(token=hf_token)
            api.upload_file(
                path_or_fileobj=filepath,
                path_in_repo=f"logs/{filename}",
                repo_id="YOUR_USERNAME/chatbot-logs",  # ← 본인 Dataset으로 변경
                repo_type="dataset",
            )
        except Exception as e:
            print(f"HF 업로드 실패: {e}")

    return gr.update(value=filepath)
```

`requirements.txt`에 `huggingface_hub` 추가:

```
google-genai
gradio
huggingface_hub
```

### 수집된 데이터 확인

- https://huggingface.co/datasets/YOUR_USERNAME/chatbot-logs 에서 확인
- `logs/` 폴더 아래 참여자별 JSON 파일이 쌓임
- 전체 다운로드: Dataset 페이지 → **Files** → 다운로드

---

## 7. 트러블슈팅

| 증상 | 해결 |
|------|------|
| API Key 오류 | https://aistudio.google.com/apikey 에서 새 키 생성 |
| pip install 실패 | 가상환경 활성화 확인: `source .venv/bin/activate` |
| HF push 인증 실패 | **Write** 토큰으로 `huggingface-cli login` 재실행 |
| HF 빌드 실패 | Space의 **Logs** 탭에서 에러 확인 |
| Windows 가상환경 오류 | PowerShell에서 `Set-ExecutionPolicy -Scope CurrentUser RemoteSigned` 실행 후 재시도 |
| HF Dataset 업로드 안 됨 | Space Settings에서 `HF_TOKEN` Secret 등록 확인 |
