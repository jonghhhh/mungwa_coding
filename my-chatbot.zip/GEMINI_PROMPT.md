# 🤖 Gemini CLI 프롬프트

VS Code 터미널에서 `gemini`를 실행하고, 아래 프롬프트를 **단계별로** 붙여넣으세요.

---

## 1단계: 가상환경 설정 및 패키지 설치

```
이 프로젝트(my-chatbot) 폴더에서 작업합니다.

1. python -m venv .venv 으로 가상환경을 생성해줘
2. 가상환경을 활성화해줘 (OS에 맞게)
3. 가상환경에서 pip install -r requirements.txt 로 라이브러리를 설치해줘

각 단계 완료 후 결과를 알려줘.
```

---

## 2단계: 로컬 테스트

```
python app.py 를 실행해서 로컬 서버를 시작해줘.
http://localhost:7860 에 접속 가능한지 확인하고 결과를 알려줘.
```

> 브라우저에서 http://localhost:7860 열어 챗봇이 잘 뜨는지 직접 확인하세요.
> 확인 후 터미널에서 Ctrl+C로 서버를 종료합니다.

---

## 3단계: Hugging Face Spaces 배포

> **사전 작업** (직접 수행):
> 1. https://huggingface.co/new-space 에서 Space 생성
>    - SDK: **Gradio** 선택 (Docker 아님!)
>    - Hardware: Free
> 2. https://huggingface.co/settings/tokens 에서 Write 토큰 복사

```
HF Spaces에 배포합니다. 아래 순서대로 실행해줘.

1. pip install huggingface_hub
2. huggingface-cli login (토큰 입력 안내): .env에서 사용할 key 찾아서 적용
3. git clone https://huggingface.co/spaces/{내아이디}/{프로젝트이름} 으로 Space를 클론
4. 현재 프로젝트의 app.py, requirements.txt, .gitignore 를 클론한 폴더에 복사
5. git add . → git commit -m "Initial deploy" → git push

Dockerfile은 복사하지 마세요. Gradio SDK가 환경을 자동 설정합니다.
각 단계 완료 후 결과를 알려줘.
```

---

## 4단계: 배포 확인 - 아래 허깅페이스에 직접 가서 확인하세요(token 절약)

```
https://{내아이디}-{프로젝트이름}.hf.space 에 접속할 수 있는지 확인해줘.
Space 상태가 Running인지도 확인해줘.
```
